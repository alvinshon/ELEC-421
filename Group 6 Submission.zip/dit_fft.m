% ELEC_V 421 101 - Digital Signal and Image Processing
% Final Project - FFT Algorithms for Audio Signal Processing
% Task 2. DIT FFT Implementation
% dit_fft.m
% 2024. Team 6 - Aaron Loh (64613987), Sam Mehrara (51595932), 
% Austin Li (91606202), Alvin Shon (36552669), James Lin (88275458), Ghassan Alrayyes (43005735)

function X = dit_fft(input_signal)
    % DIT_FFT Implements the Decimation-in-Time (DIT) FFT algorithm recursively.
    % Handles non-power-of-2 inputs by internally padding to the nearest power of 2.
    % Inputs:
    %   input_signal - 1D array of the input signal.
    % Outputs:
    %   X - FFT of the input signal (in-order result).

    % Ensure input_signal is a row vector
    input_signal = input_signal(:).'; % Convert to row vector

    % Zero-pad input signal to the nearest power of 2
    padded_length = 2^ceil(log2(length(input_signal)));
    input_signal = [input_signal, zeros(1, padded_length - length(input_signal))];

    signal_length = length(input_signal); % Length of the padded input signal

    % Base case: if the signal length is 1, return the input
    if signal_length <= 1
        X = input_signal;
        return;
    end

    % Split signal into even and odd indices
    even_group = input_signal(1:2:end); % Elements at even indices
    odd_group = input_signal(2:2:end); % Elements at odd indices

    % Recursively compute FFT on the even and odd parts
    FFT_even = dit_fft(even_group);
    FFT_odd = dit_fft(odd_group);

    % Combine results using the butterfly computation
    X = zeros(1, signal_length); % Pre-allocate output array
    for k = 1:signal_length/2
        twiddle_factor = exp(-1j * 2 * pi * (k-1) / signal_length);
        X(k) = FFT_even(k) + twiddle_factor * FFT_odd(k);
        X(k + signal_length/2) = FFT_even(k) - twiddle_factor * FFT_odd(k);
    end
end