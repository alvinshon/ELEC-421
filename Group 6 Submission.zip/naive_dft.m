% ELEC_V 421 101 - Digital Signal and Image Processing
% Final Project - FFT Algorithms for Audio Signal Processing
% Task 1. Naive DFT Implementation
% naive_dft.m
% 2024. Team 6 - Aaron Loh (64613987), Sam Mehrara (51595932), 
% Austin Li (91606202), Alvin Shon (36552669), James Lin (88275458), Ghassan Alrayyes (43005735)

function X = naive_dft(input_signal)
    % NAIVE_DFT Computes the Discrete Fourier Transform (DFT) using a naive O(N^2) approach.
    % Inputs:
    %   input_signal - 1D array of the input signal.
    % Outputs:
    %   X - DFT of the input signal (1D array).
    
    % Convert to row vector
    input_signal = input_signal(:).'; 

    % Signal length
    N = length(input_signal);
    X = zeros(1, N);  % Pre-allocate output array
    
    % Compute DFT using nested loops
    for k = 1:N
        for n = 1:N
            X(k) = X(k) + input_signal(n) * exp(-1j * 2 * pi * (k-1) * (n-1) / N);
        end
    end
end
