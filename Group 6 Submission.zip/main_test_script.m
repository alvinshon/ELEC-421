% ELEC_V 421 101 - Digital Signal and Image Processing
% Final Project - FFT Algorithms Testing and Analysis
% main_test_script.m
% 2024. Team 6 - Aaron Loh (64613987), Sam Mehrara (51595932), 
% Austin Li (91606202), Alvin Shon (36552669), James Lin (88275458), Ghassan Alrayyes (43005735)

% This script performs the following analyses:
% 1. Verifies the accuracy of the Naive DFT, DIT FFT, and DIF FFT implementations by comparing their results with MATLAB's built-in FFT.
% 2. Analyzes execution time of the Naive DFT, DIT FFT, and DIF FFT across various signal lengths.
% 3. Analyzes clean and noisy audio signals using DIT FFT, DIF FFT, and MATLAB's built-in FFT, comparing their magnitude spectra.

clear; clc; close all;

%% 1. Verify Algorithm Accuracy Against Built-in MATLAB FFT
disp('1. Verifying Algorithm Accuracy');

% Test signals
test_signal_lengths = [64, 128, 256];
for len = test_signal_lengths
    test_signal = rand(1, len);  % Generate random test signal
    
    % Compute FFTs using each method
    fft_builtin = fft(test_signal);
    fft_naive = naive_dft(test_signal);
    fft_dit = dit_fft(test_signal);
    fft_dif = dif_fft(test_signal);
    
    % Check results and report
    fprintf('Signal Length: %d\n', len);
    
    % Naive DFT
    if norm(fft_naive - fft_builtin) < 1e-10
        disp('[PASS] Naive DFT matches Built-in FFT');
    else
        disp('[ERROR] Naive DFT does not match Built-in FFT');
    end
    
    % DIT FFT
    if norm(fft_dit - fft_builtin) < 1e-10
        disp('[PASS] DIT FFT matches Built-in FFT');
    else
        disp('[ERROR] DIT FFT does not match Built-in FFT');
    end
    
    % DIF FFT
    if norm(fft_dif - fft_builtin) < 1e-10
        disp('[PASS] DIF FFT matches Built-in FFT');
    else
        disp('[ERROR] DIF FFT does not match Built-in FFT');
    end
    fprintf('\n');
end

%% 2. Performance Testing
disp('2. Performing Execution Time Analysis (Figure 1)');

signal_lengths = [64, 100, 128, 150, 200, 256, 300, 400, 512, 600, 800, 1024, 1200, 1500, 1800, 2000];
execution_times_naive = zeros(1, length(signal_lengths));
execution_times_dit = zeros(1, length(signal_lengths));
execution_times_dif = zeros(1, length(signal_lengths));

for idx = 1:length(signal_lengths)
    len = signal_lengths(idx);
    test_signal = rand(1, len);
    
    % Measure execution time for each algorithm
    tic;
    naive_dft(test_signal);
    execution_times_naive(idx) = toc;
    
    tic;
    dit_fft(test_signal);
    execution_times_dit(idx) = toc;
    
    tic;
    dif_fft(test_signal);
    execution_times_dif(idx) = toc;
end

% Plot performance comparison
figure;
semilogy(signal_lengths, execution_times_naive, '-+', 'LineWidth', 1.5, 'DisplayName', 'Naive DFT');
hold on;
semilogy(signal_lengths, execution_times_dit, '-o', 'LineWidth', 1.5, 'DisplayName', 'DIT FFT');
semilogy(signal_lengths, execution_times_dif, '-x', 'LineWidth', 1.5, 'DisplayName', 'DIF FFT');
xlabel('Signal Length (N)', 'FontWeight', 'bold');
ylabel('Execution Time (seconds, log scale)', 'FontWeight', 'bold');
title('Performance Comparison: Naive DFT vs. DIT FFT vs. DIF FFT', 'FontWeight', 'bold');
legend('show', 'Location', 'northwest');
grid on;

%% 3. Audio Signal Analysis
disp('3. Analyzing Audio Signals (Clean Signal & Noisy Signal)');

% Load audio signals
[clean_signal, clean_fs] = audioread('clean_signal.wav');
[noisy_signal, noisy_fs] = audioread('noisy_signal.wav');

audio_signals = {clean_signal, noisy_signal};
sampling_rates = [clean_fs, noisy_fs];
titles = {'Clean Signal', 'Noisy Signal'};

for sig_idx = 1:2
    signal = audio_signals{sig_idx};
    fs = sampling_rates(sig_idx);
    N = length(signal);
    freq_axis = (0:N/2) * (fs / N);  % Frequency axis for FFT result
    
    % Compute FFTs
    fft_builtin = fft(signal);
    fft_naive = naive_dft(signal);
    fft_dit = dit_fft(signal);
    fft_dif = dif_fft(signal);
    
    % Magnitude spectra
    mag_builtin = abs(fft_builtin(1:N/2+1));
    mag_naive = abs(fft_naive(1:N/2+1));
    mag_dit = abs(fft_dit(1:N/2+1));
    mag_dif = abs(fft_dif(1:N/2+1));
    
    % Plot results
    figure('Name', titles{sig_idx}, 'NumberTitle', 'off');
    subplot(4, 1, 1);
    plot(freq_axis, mag_builtin, 'LineWidth', 1.5);
    title(['Built-in FFT (', titles{sig_idx}, ')']);
    xlabel('Frequency (Hz)'); ylabel('Magnitude'); grid on;

    subplot(4, 1, 2);
    plot(freq_axis, mag_naive, 'LineWidth', 1.5);
    title(['Naive DFT (', titles{sig_idx}, ')']);
    xlabel('Frequency (Hz)'); ylabel('Magnitude'); grid on;

    subplot(4, 1, 3);
    plot(freq_axis, mag_dit, 'LineWidth', 1.5);
    title(['DIT FFT (', titles{sig_idx}, ')']);
    xlabel('Frequency (Hz)'); ylabel('Magnitude'); grid on;
    
    subplot(4, 1, 4);
    plot(freq_axis, mag_dif, 'LineWidth', 1.5);
    title(['DIF FFT (', titles{sig_idx}, ')']);
    xlabel('Frequency (Hz)'); ylabel('Magnitude'); grid on;
    
    sgtitle(['Comparison of FFT Methods - ', titles{sig_idx}], 'FontWeight', 'bold');
end

disp('All Analysis Done.');
