% ELEC_V 421 101 - Digital Signal and Image Processing
% Final Project - FFT Algorithms for Audio Signal Processing
% Task 3. DIF FFT Implementation
% dif_fft.m
% 2024. Team 6 - Aaron Loh (64613987), Sam Mehrara (51595932), 
% Austin Li (91606202), Alvin Shon (36552669), James Lin (88275458), Ghassan Alrayyes (43005735)



function X = dif_fft(input_signal)
    % DIF_FFT Iterative Decimation-in-Frequency FFT Implementation.
    % Handles non-power-of-2 inputs by internally padding to the nearest power of 2.
    % Produces output in bit-reversed order.

    % Ensure input_signal is a row vector
    input_signal = input_signal(:).'; % Convert to row vector

    % Zero-pad input signal to the nearest power of 2
    padded_length = 2^ceil(log2(length(input_signal)));
    input_signal = [input_signal, zeros(1, padded_length - length(input_signal))];

    % Signal length after padding
    N = length(input_signal);
    X = input_signal;  % Initialize output with input signal

    % Iterative DIF FFT stages
    for stage = log2(N):-1:1
        half_stage_size = 2^(stage - 1); % Half of the current stage size
        full_stage_size = 2^stage; % Full stage size

        for k = 0:(N/full_stage_size - 1) % Process groups of size `full_stage_size`
            for j = 0:(half_stage_size - 1) % Butterfly operations within each group
                twiddle_factor = exp(-1j * 2 * pi * j / full_stage_size);
                temp = X(k * full_stage_size + j + 1);
                X(k * full_stage_size + j + 1) = temp + X(k * full_stage_size + j + half_stage_size + 1);
                X(k * full_stage_size + j + half_stage_size + 1) = (temp - X(k * full_stage_size + j + half_stage_size + 1)) * twiddle_factor;
            end
        end
    end

    % Bit-reversal reordering ensures the final result matches DIF FFT output
    X = bitrevorder(X);
end
